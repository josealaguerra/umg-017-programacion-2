/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.portales.domingo.progra2.grupo12.farmaciajutiapa.modelo;

import java.util.Date;

/**
 *
 * @author josea
 */
public class venta {
    private int id_venta;
    private int id_cliente;
    private Date fecha_venta;
    private String numero_factura;
    private double monto_total;
}
